﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BasicCalculetor
{
    interface basicCalculators
    {
        void Sum(int x, int y);
        void Sub(int x, int y);
        void Multiplication(int x, int y);
        void Devision(int x, int y);


    }
}
