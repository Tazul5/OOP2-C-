﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BasicCalculetor
{
    class Function:  Calculator, basicCalculators, ScientificCalculator
    {
        public Function()
        {

        }

        public Function(string name, string taskType) : base(name, taskType)
        {

        }
        public void Devision(int x, int y)
        {
            int div = x / y;
            Console.WriteLine("The devision is : " + div);
        }

        public void Multiplication(int x, int y)
        {
            int mul = x * y;
            Console.WriteLine(" Multiplication  : " + mul);
        }

        public void Sub(int x, int y)
        {
            int sub = x - y;
            Console.WriteLine(" Sub : " + sub);
        }

        public void Sum(int x, int y)
        {
            int sum = x + y;
            Console.WriteLine("Sum : " + sum);
        }

        public void sc(int x, int y)
        {

            double sc = Math.Pow(x, y);
            Console.WriteLine(" XtoY : " + sc);
        }
    }
}
