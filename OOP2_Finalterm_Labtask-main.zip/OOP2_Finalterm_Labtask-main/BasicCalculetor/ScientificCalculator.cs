﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BasicCalculetor
{
    interface ScientificCalculator
    {
        void sc(int x, int y);
    }
}
