﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RadioPlayer_Interface
{
    class Phone : IMusicPlayer, IRadioPlayer
    {
        public void ChangeChannel()
        {
            Console.WriteLine(" Channel changed ");
        }

        public void Play(bool on)
        {
            Console.WriteLine("Playing Music");
        }

        public void PlayNext()
        {
            Console.WriteLine("Playing Next Music");
        }

        public void PlayPrevious()
        {
            Console.WriteLine("Playing Previous Music");
        }

        public void Retune(double frequency)
        {
            Console.WriteLine("Retuning to " + frequency);
        }

        public void SetVolume(int loudness)
        {
            Console.WriteLine(" volume is " + loud);
        }

        public void Switch(bool on)
        {
            Console.WriteLine(" switch ON");
        }
    }
}
