﻿using System;

namespace Account
{
    class Program
    {
        static void Main(string[] args)
        {
            Accounts acc1 = new Savings();
            Accounts acc2 = new Savings("X", 1110000, 10000);
            Accounts acc3 = new SpecialSavings("Y", 900000, 22000, 25);
            Accounts acc4 = new Fixed("X",90000, 5000);
            Accounts acc5 = new Overdraft(1990);
            SpecialSavings s1 = new SpecialSavings(25);
            Overdraft od = new Overdraft("X", 400000, 10000, 4400);
        }
    }
}
