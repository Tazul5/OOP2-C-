﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3
{
    class Program
    {
        static void Main(string[] args)
        {
            Student s = new Student();
            s.Name = "Tazul";
            s.Id = "19-39341-1";
            s.Department = "CSE";
            s.Cgpa =0.00
            s.ShowInfo();
            Triangle t = new Triangle();
            t.X = 5;
            t.X = 8;
            t.Z = 5;
            t.ShowInfo();
            t.TestTriangle();
            Account a = new Account();
            a.AccName = "My Account";
            a.AcId = "1";
            a.Balance = 5000;
            a.Deposit(1200);
            a.Withdraw(400);
            Course c = new Course();
            c.CourseName = "OOP2";
            c.CourseId = "1011";
            c.CourseCredit = 3;
            c.ShowCourseInfo();
        }
    }

}
