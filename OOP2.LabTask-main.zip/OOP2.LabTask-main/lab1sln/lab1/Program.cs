﻿using System;

namespace lab1
{
    class Program
    {
        static void Main(string[] args)
        {/*//ans 01
            Console.WriteLine("Hello ");
             Console.WriteLine("Tazul ");*/
            /* //ans 02
             int a, b,sum;
             a = 7;
             b = 35;
             sum = a + b;
             Console.WriteLine("The Sum of two number A and B is: " + sum);
             Console.ReadLine();*/
            /* //ans 03
             int a, b, div;
             a = 7;
             b = 35;
             div = b / a;
             Console.WriteLine("The Dividation of two number A and B is: " + div);
             Console.ReadLine();*/

            /*//ans 04
            int a = (-5 + 8 * 6);
            int b = ((55 + 9) % 9);
            int c = (20 + -3 * 5 / 8);
            int d = (5 + 15 / 3 * 2 - 8 % 3);
            Console.WriteLine("The answer of A: "+a);
            Console.WriteLine("The answer of b: " + b);
            Console.WriteLine("The answer of c: " + c);
            Console.WriteLine("The answer of d: " + d);
            Console.ReadLine();*/
            /*//ans 05
            int a, b,add,mul,sub, div;
            a = 7;
            b = 35;
            add = a + b;
            mul = a * b;
            sub = b - a;
            div = b / a;
            Console.WriteLine("The Sum of two number A and B is: " + add);
            Console.WriteLine("The Multipication of two number A and B is: " + mul);
            Console.WriteLine("The substraction of two number A and B is: " + sub);
            Console.WriteLine("The Dividation of two number A and B is: " + div);
            Console.ReadLine();*/
            /* //ans 06
             double e = ((25.5 * 3.5 - 3.5 * 3.5) / (40.5 - 4.5));
             Console.WriteLine("compute the specified expressions is: " + e);
             Console.WriteLine();
            */
            /* //ans 07
            double Width = 5.5, Height = 8.5;
             double Perimeter = (2 * (Width + Height));
              double   Area = Width * Height;

             Console.WriteLine("Area is 5.6 * 8.5 =" +Area);
             Console.WriteLine("Perimeter is 2 * (5.6 + 8.5) =" + Perimeter);
             Console.ReadLine();*/
            
        }
    }
}
